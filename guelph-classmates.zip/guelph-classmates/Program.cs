using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.Sqlite;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options =>
{
    options.LoginPath = "/login";
    options.Cookie.HttpOnly = true;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.ExpireTimeSpan = TimeSpan.FromDays(14);
});
builder.Services.AddAuthorization();
builder.Services.AddAntiforgery(options => options.FormFieldName = "csrf");
builder.Services.AddSingleton<PasswordHasher<Member>>();
builder.Services.AddSingleton<Store>();
var app = builder.Build();
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
await app.Services.GetRequiredService<Store>().Initialize();
await app.Services.GetRequiredService<Store>().BootstrapAdmin(app.Services.GetRequiredService<PasswordHasher<Member>>(), Environment.GetEnvironmentVariable("ADMIN_EMAIL"), Environment.GetEnvironmentVariable("ADMIN_PASSWORD"));

string E(string? s) => WebUtility.HtmlEncode(s ?? "");
string Layout(HttpContext ctx, string title, string content)
{
    var signed = ctx.User.Identity?.IsAuthenticated == true;
    var admin = ctx.User.IsInRole("Admin");
    var links = signed ? $"<a href='/directory'>Directory</a><a href='/verify'>Verify classmates</a>{(admin ? "<a href='/admin'>Administration</a>" : "")}<form method='post' action='/logout' class='inline'>{Token(ctx)}<button class='link'>Sign out</button></form>" : "<a href='/login'>Sign in</a><a href='/register'>Register</a>";
    return $"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{E(title)} · Guelph Classmates</title><link rel='stylesheet' href='/site.css'></head><body><header><div class='shell nav'><a class='brand' href='/'>GUELPH <span>1976–1980</span></a><nav>{links}</nav></div></header><main class='shell'>{content}</main><footer class='shell'>University of Guelph classmates, 1976–1980 · Independent alumni community, not affiliated with the University.</footer></body></html>";
}
string Token(HttpContext ctx) => $"<input type='hidden' name='csrf' value='{E(ctx.RequestServices.GetRequiredService<IAntiforgery>().GetAndStoreTokens(ctx).RequestToken)}'>";
IResult Page(HttpContext ctx, string title, string html, int status = 200) => Results.Content(Layout(ctx, title, html), "text/html; charset=utf-8", statusCode: status);
IResult Error(HttpContext ctx, string message, int status = 400) => Page(ctx, "Problem", $"<section class='panel'><h1>Unable to continue</h1><p>{E(message)}</p><p><a href='javascript:history.back()'>Go back</a></p></section>", status);
string Field(string name, string label, string type = "text", bool required = true, string extra = "") => $"<label>{E(label)}<input name='{E(name)}' type='{E(type)}' {(required ? "required" : "")} {extra}></label>";
long Id(HttpContext ctx) => long.TryParse(ctx.User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : 0;

app.MapGet("/", (HttpContext ctx) => Page(ctx, "Welcome", "<section class='hero'><p class='eyebrow'>University of Guelph · 1976–1980</p><h1>Old friends. New conversations.</h1><p>Reconnect with the people who shared your Guelph years. A private community where classmates verify classmates.</p><p><a class='button' href='/register'>Join the community</a> <a class='button ghost' href='/login'>Member sign in</a></p></section><section class='grid'><article class='panel'><h2>Reconnect</h2><p>Find classmates by the names they used on campus.</p></article><article class='panel'><h2>Keep it private</h2><p>Two verified classmates must recognize you before membership becomes active.</p></article><article class='panel'><h2>Share memories</h2><p>Build connections and help organize future reunions.</p></article></section>"));

app.MapGet("/register", (HttpContext ctx) => Page(ctx, "Register", $"<section class='panel narrow'><p class='eyebrow'>Join the community</p><h1>Classmate registration</h1><p>Tell us how classmates knew you at Guelph. Your application stays private until verified.</p><form method='post' action='/register'>{Token(ctx)}{Field("email","Email address","email")}{Field("password","Password (12 characters minimum)","password",true,"minlength='12'")}{Field("currentName","Current full name")}{Field("campusName","Name used at Guelph")}{Field("program","Program or area of study", "text",false)}{Field("years","Years attended (e.g. 1976–1980)")}{Field("residence","Residence or campus group", "text",false)}<label class='check'><input type='checkbox' name='consent' value='yes' required> I understand my profile will be visible to verified members after approval.</label><button class='button'>Submit application</button></form></section>"));
app.MapPost("/register", async (HttpContext ctx, Store db, PasswordHasher<Member> hasher) =>
{
    var f = await ctx.Request.ReadFormAsync();
    string V(string k) => f[k].ToString().Trim();
    if (V("consent") != "yes" || V("password").Length < 12 || !V("email").Contains('@') || new[]{"currentName","campusName","years"}.Any(k => V(k).Length is 0 or > 150)) return Error(ctx, "Please complete the required fields. Passwords must be at least 12 characters.");
    var m = new Member { Email = V("email").ToLowerInvariant(), CurrentName = V("currentName"), CampusName = V("campusName"), Program = V("program"), Years = V("years"), Residence = V("residence"), Status = "Pending" };
    m.PasswordHash = hasher.HashPassword(m, V("password"));
    if (!await db.Create(m)) return Error(ctx, "That email is already registered.");
    return Page(ctx, "Application received", "<section class='panel narrow'><h1>Application received</h1><p>Your membership is pending. Confirm your email using the link sent by your administrator, then wait for two verified classmates to recognize you.</p><p><strong>Note:</strong> Automated email delivery is not configured in this starter deployment. Ask the administrator to verify your email after confirming ownership.</p><a href='/login'>Sign in</a></section>");
}).AddEndpointFilter<ValidateCsrf>();

app.MapGet("/login", (HttpContext ctx) => Page(ctx, "Sign in", $"<section class='panel narrow'><h1>Member sign in</h1><form method='post' action='/login'>{Token(ctx)}{Field("email","Email","email")}{Field("password","Password","password")}<button class='button'>Sign in</button></form></section>"));
app.MapPost("/login", async (HttpContext ctx, Store db, PasswordHasher<Member> hasher) =>
{
    var f = await ctx.Request.ReadFormAsync();
    var member = await db.ByEmail(f["email"].ToString().Trim().ToLowerInvariant());
    if (member is null || hasher.VerifyHashedPassword(member, member.PasswordHash, f["password"].ToString()) == PasswordVerificationResult.Failed) return Error(ctx, "Incorrect email or password.", 401);
    if (member.Status == "Suspended") return Error(ctx, "This account is suspended.", 403);
    var claims = new List<Claim> { new(ClaimTypes.NameIdentifier, member.Id.ToString()), new(ClaimTypes.Name, member.CurrentName), new(ClaimTypes.Role, member.IsAdmin ? "Admin" : "Member") };
    await ctx.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme)));
    return Results.Redirect(member.IsAdmin ? "/admin" : member.Status == "Active" ? "/directory" : "/pending");
}).AddEndpointFilter<ValidateCsrf>();
app.MapPost("/logout", async (HttpContext ctx) => { await ctx.SignOutAsync(); return Results.Redirect("/"); }).RequireAuthorization().AddEndpointFilter<ValidateCsrf>();

app.MapGet("/pending", async (HttpContext ctx, Store db) =>
{
    var m = await db.ById(Id(ctx));
    if (m is null) return Results.Redirect("/login");
    var n = await db.Confirmations(m.Id);
    return Page(ctx, "Membership pending", $"<section class='panel narrow'><p class='eyebrow'>Application status</p><h1>{E(m.Status == "Active" ? "Membership active" : "Waiting for classmates")}</h1><p>{n} of 2 confirmations received.</p><div class='meter'><span style='width:{Math.Min(100,n*50)}%'></span></div><p>Applications without two confirmations remain pending. Contact an administrator if your details need correction.</p></section>");
}).RequireAuthorization();

app.MapGet("/verify", async (HttpContext ctx, Store db) =>
{
    var me = await db.ById(Id(ctx));
    if (me?.Status != "Active") return Results.Redirect("/pending");
    var candidates = await db.Pending();
    var cards = new StringBuilder();
    foreach (var m in candidates.Where(x => x.Id != me.Id))
    {
        var confirmed = await db.HasConfirmed(me.Id, m.Id);
        var n = await db.Confirmations(m.Id);
        cards.Append($"<article class='panel'><h2>{E(m.CampusName)}</h2><p><strong>Current name:</strong> {E(m.CurrentName)}<br><strong>Program:</strong> {E(m.Program)}<br><strong>Years:</strong> {E(m.Years)}<br><strong>Residence/group:</strong> {E(m.Residence)}</p><p>{n} of 2 confirmations</p>{(confirmed ? "<p class='success'>You have confirmed this classmate.</p>" : $"<form method='post' action='/verify/{m.Id}'>{Token(ctx)}<button class='button'>I recognize this classmate</button></form>")}</article>");
    }
    return Page(ctx, "Verify classmates", $"<h1>Recognize a classmate</h1><p>Only confirm people whose identity you personally recognize. A second independent confirmation is required.</p><div class='grid'>{(cards.Length == 0 ? "<p>No applications currently need confirmation.</p>" : cards.ToString())}</div>");
}).RequireAuthorization();
app.MapPost("/verify/{id:long}", async (long id, HttpContext ctx, Store db) =>
{
    var me = await db.ById(Id(ctx));
    if (me?.Status != "Active" || me.Id == id) return Error(ctx, "You cannot confirm this application.", 403);
    await db.Confirm(me.Id, id);
    return Results.Redirect("/verify");
}).RequireAuthorization().AddEndpointFilter<ValidateCsrf>();

app.MapGet("/directory", async (HttpContext ctx, Store db) =>
{
    var me = await db.ById(Id(ctx));
    if (me?.Status != "Active") return Results.Redirect("/pending");
    var members = await db.Active();
    var cards = string.Join("", members.Select(m => $"<article class='panel'><h2>{E(m.CampusName)}</h2><p>{E(m.CurrentName)}<br>{E(m.Program)}<br>{E(m.Years)}<br>{E(m.Residence)}</p></article>"));
    return Page(ctx, "Classmate directory", $"<h1>Classmate directory</h1><p>Visible only to verified members. Email addresses are never shown here.</p><div class='grid'>{cards}</div>");
}).RequireAuthorization();

app.MapGet("/admin", async (HttpContext ctx, Store db) =>
{
    var members = await db.All();
    var rows = new StringBuilder();
    foreach (var m in members)
    {
        var n = await db.Confirmations(m.Id);
        rows.Append($"<tr><td>{E(m.CampusName)}<small>{E(m.CurrentName)}</small></td><td>{E(m.Email)}</td><td>{E(m.Status)}</td><td>{n}/2</td><td>{(m.IsAdmin ? "Administrator" : $"<form method='post' action='/admin/{m.Id}/suspend'>{Token(ctx)}<button class='small'>Suspend</button></form>")}{(m.Status == "Pending" ? $"<form method='post' action='/admin/{m.Id}/emailverified'>{Token(ctx)}<button class='small'>Mark email verified</button></form>" : "")}</td></tr>");
    }
    return Page(ctx, "Administration", $"<h1>Member administration</h1><p>Review applications and suspend accounts. Two independent confirmations are always required for activation.</p><div class='tablewrap'><table><thead><tr><th>Classmate</th><th>Email</th><th>Status</th><th>Confirmations</th><th>Actions</th></tr></thead><tbody>{rows}</tbody></table></div>");
}).RequireAuthorization(policy => policy.RequireRole("Admin"));
app.MapPost("/admin/{id:long}/suspend", async (long id, HttpContext ctx, Store db) => { if (id != Id(ctx)) await db.Suspend(id); return Results.Redirect("/admin"); }).RequireAuthorization(policy => policy.RequireRole("Admin")).AddEndpointFilter<ValidateCsrf>();
app.MapPost("/admin/{id:long}/emailverified", async (long id, Store db) => { await db.VerifyEmail(id); return Results.Redirect("/admin"); }).RequireAuthorization(policy => policy.RequireRole("Admin")).AddEndpointFilter<ValidateCsrf>();

app.Run();

sealed class ValidateCsrf : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var antiforgery = context.HttpContext.RequestServices.GetRequiredService<IAntiforgery>();
        try { await antiforgery.ValidateRequestAsync(context.HttpContext); }
        catch (AntiforgeryValidationException) { return Results.BadRequest("Invalid form token. Refresh the page and try again."); }
        return await next(context);
    }
}
sealed class Member
{
    public long Id { get; set; }
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string CurrentName { get; set; } = "";
    public string CampusName { get; set; } = "";
    public string Program { get; set; } = "";
    public string Years { get; set; } = "";
    public string Residence { get; set; } = "";
    public string Status { get; set; } = "Pending";
    public bool IsAdmin { get; set; }
    public bool EmailVerified { get; set; }
}
sealed class Store(IConfiguration config)
{
    SqliteConnection Open() => new(config.GetConnectionString("Default") ?? "Data Source=classmates.db");
    public async Task BootstrapAdmin(PasswordHasher<Member> hasher, string? email, string? password)
    {
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) || password.Length < 12) return;
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();
        cmd.CommandText="SELECT COUNT(*) FROM Members WHERE IsAdmin=1";
        if (Convert.ToInt32(await cmd.ExecuteScalarAsync())!=0) return;
        var m=new Member { Email=email.Trim().ToLowerInvariant(), CurrentName="Site administrator", CampusName="Administrator" };
        var hash=hasher.HashPassword(m,password);
        cmd.CommandText="INSERT OR IGNORE INTO Members(Email,PasswordHash,CurrentName,CampusName,Program,Years,Residence,Status,IsAdmin,EmailVerified) VALUES($email,$hash,'Site administrator','Administrator','','','','Active',1,1)";
        cmd.Parameters.AddWithValue("$email",m.Email);cmd.Parameters.AddWithValue("$hash",hash);await cmd.ExecuteNonQueryAsync();
    }
    public async Task Initialize()
    {
        using var db = Open(); await db.OpenAsync();
        using var cmd = db.CreateCommand();
        cmd.CommandText = "PRAGMA foreign_keys=ON; CREATE TABLE IF NOT EXISTS Members(Id INTEGER PRIMARY KEY AUTOINCREMENT, Email TEXT NOT NULL UNIQUE, PasswordHash TEXT NOT NULL, CurrentName TEXT NOT NULL, CampusName TEXT NOT NULL, Program TEXT NOT NULL, Years TEXT NOT NULL, Residence TEXT NOT NULL, Status TEXT NOT NULL, IsAdmin INTEGER NOT NULL DEFAULT 0, EmailVerified INTEGER NOT NULL DEFAULT 0); CREATE TABLE IF NOT EXISTS Confirmations(VerifierId INTEGER NOT NULL, ApplicantId INTEGER NOT NULL, CreatedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(VerifierId,ApplicantId), FOREIGN KEY(VerifierId) REFERENCES Members(Id), FOREIGN KEY(ApplicantId) REFERENCES Members(Id));";
        await cmd.ExecuteNonQueryAsync();
    }
    static Member Read(SqliteDataReader r) => new() { Id=r.GetInt64(0),Email=r.GetString(1),PasswordHash=r.GetString(2),CurrentName=r.GetString(3),CampusName=r.GetString(4),Program=r.GetString(5),Years=r.GetString(6),Residence=r.GetString(7),Status=r.GetString(8),IsAdmin=r.GetInt64(9)!=0,EmailVerified=r.GetInt64(10)!=0 };
    async Task<List<Member>> Query(string sql, params (string,object)[] args)
    {
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();cmd.CommandText=sql;
        foreach(var (k,v) in args)cmd.Parameters.AddWithValue(k,v);
        using var r=await cmd.ExecuteReaderAsync();var result=new List<Member>();while(await r.ReadAsync())result.Add(Read(r));return result;
    }
    const string Columns="SELECT Id,Email,PasswordHash,CurrentName,CampusName,Program,Years,Residence,Status,IsAdmin,EmailVerified FROM Members";
    public async Task<Member?> ById(long id)=>(await Query(Columns+" WHERE Id=$id",("$id",id))).FirstOrDefault();
    public async Task<Member?> ByEmail(string email)=>(await Query(Columns+" WHERE Email=$email",("$email",email))).FirstOrDefault();
    public Task<List<Member>> All()=>Query(Columns+" ORDER BY Id DESC");
    public Task<List<Member>> Pending()=>Query(Columns+" WHERE Status='Pending' ORDER BY Id DESC");
    public Task<List<Member>> Active()=>Query(Columns+" WHERE Status='Active' ORDER BY CampusName");
    public async Task<bool> Create(Member m)
    {
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();
        cmd.CommandText="INSERT INTO Members(Email,PasswordHash,CurrentName,CampusName,Program,Years,Residence,Status) VALUES($email,$hash,$current,$campus,$program,$years,$residence,'Pending')";
        cmd.Parameters.AddWithValue("$email",m.Email);cmd.Parameters.AddWithValue("$hash",m.PasswordHash);cmd.Parameters.AddWithValue("$current",m.CurrentName);cmd.Parameters.AddWithValue("$campus",m.CampusName);cmd.Parameters.AddWithValue("$program",m.Program);cmd.Parameters.AddWithValue("$years",m.Years);cmd.Parameters.AddWithValue("$residence",m.Residence);
        try { await cmd.ExecuteNonQueryAsync();return true; }catch(SqliteException e) when(e.SqliteErrorCode==19){return false;}
    }
    public async Task<int> Confirmations(long id)
    {
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();cmd.CommandText="SELECT COUNT(*) FROM Confirmations WHERE ApplicantId=$id";cmd.Parameters.AddWithValue("$id",id);return Convert.ToInt32(await cmd.ExecuteScalarAsync());
    }
    public async Task<bool> HasConfirmed(long verifier,long applicant)
    {
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();cmd.CommandText="SELECT COUNT(*) FROM Confirmations WHERE VerifierId=$v AND ApplicantId=$a";cmd.Parameters.AddWithValue("$v",verifier);cmd.Parameters.AddWithValue("$a",applicant);return Convert.ToInt32(await cmd.ExecuteScalarAsync())>0;
    }
    public async Task Confirm(long verifier,long applicant)
    {
        using var db=Open();await db.OpenAsync();using var transaction=await db.BeginTransactionAsync();
        using var cmd=db.CreateCommand();cmd.Transaction=(SqliteTransaction)transaction;
        cmd.CommandText="INSERT OR IGNORE INTO Confirmations(VerifierId,ApplicantId) SELECT $v,$a WHERE $v<>$a AND EXISTS(SELECT 1 FROM Members WHERE Id=$v AND Status='Active') AND EXISTS(SELECT 1 FROM Members WHERE Id=$a AND Status='Pending')";
        cmd.Parameters.AddWithValue("$v",verifier);cmd.Parameters.AddWithValue("$a",applicant);await cmd.ExecuteNonQueryAsync();
        cmd.CommandText="UPDATE Members SET Status='Active' WHERE Id=$a AND Status='Pending' AND EmailVerified=1 AND (SELECT COUNT(*) FROM Confirmations WHERE ApplicantId=$a)>=2";await cmd.ExecuteNonQueryAsync();await transaction.CommitAsync();
    }
    public async Task VerifyEmail(long id)
    {
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();cmd.CommandText="UPDATE Members SET EmailVerified=1, Status=CASE WHEN Status='Pending' AND (SELECT COUNT(*) FROM Confirmations WHERE ApplicantId=$id)>=2 THEN 'Active' ELSE Status END WHERE Id=$id";cmd.Parameters.AddWithValue("$id",id);await cmd.ExecuteNonQueryAsync();
    }
    public async Task Suspend(long id)
    {
        using var db=Open();await db.OpenAsync();using var cmd=db.CreateCommand();cmd.CommandText="UPDATE Members SET Status='Suspended' WHERE Id=$id AND IsAdmin=0";cmd.Parameters.AddWithValue("$id",id);await cmd.ExecuteNonQueryAsync();
    }
}
