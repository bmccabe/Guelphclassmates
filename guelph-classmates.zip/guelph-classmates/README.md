# University of Guelph 1976–1980 Classmates

An ASP.NET Core 8 / SQLite membership website with registration, password sign-in, a private directory, classmate confirmation and administration.

## Setup

1. Install the .NET 8 SDK (or update the project to a supported LTS version).
2. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` environment variables. The password must be at least 12 characters. These values create the initial administrator on first launch; never commit them to source control.
3. Run `dotnet restore` and `dotnet run` from this directory.
4. Open the HTTPS URL shown in the console and sign in as the administrator.

On first launch, `classmates.db` is created automatically. Back it up securely. The initial administrator is the only automatically active account; they can verify email ownership for applicants, but cannot bypass the two-member confirmation rule.

## Membership rules

- Applicants supply current name, campus-era name, years, program and optional residence.
- New accounts are `Pending` and cannot view the directory or verify others.
- Two **different active members** must confirm the applicant.
- Applicant must also have `EmailVerified=1`; the administrator currently marks this manually after checking email ownership.
- Unrecognized applicants remain pending indefinitely.
- Administrators can suspend non-admin members.

## Important deployment work

This is a runnable first version, **not yet production-ready for a public Internet launch**. Before publishing, add automated email verification (time-limited signed links), password reset, rate limiting and account lockout, abuse monitoring, administrator audit logs, user self-service profile updates, privacy policy/consent and data deletion, backup/restore tests, and deployment behind HTTPS with secure hosting and secrets management. Consider additional safeguards against coordinated fraudulent endorsements. The current manual email verification is only appropriate for a small private pilot with an administrator who checks ownership through a separate channel.

This independent alumni site is not affiliated with the University of Guelph. Use only photographs and branding you have permission to publish.
